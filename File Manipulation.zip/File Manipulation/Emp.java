public class Emp{
	
	Int Id;
	String Name;
	void Emp(Int Id, String Name)
	{
		this.Name = Name;
		this.Id = Id;
		
	}
	
}