pubic class AccountCl{
	Id; Name; 
	
	
	
}