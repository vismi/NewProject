 
public class Employee{
	int EmpId;
	String Name;
	int Salary;
	void Add(int EmpId, String Name, int Salary)
	{
		this.EmpId = EmpId;
		this.Name = Name;
		this.Salary = Salary;
	}
}

